// ---------- DATA (in-memory, resets on page reload) ----------
let rooms = [
  { id:1, name:"Room A-101", type:"Single", price:4500, total:1, booked:0, icon:"🛏️", desc:"Cozy single room with attached bath." },
  { id:2, name:"Room A-102", type:"Single", price:4500, total:1, booked:1, icon:"🛏️", desc:"Quiet corner room, great for studying." },
  { id:3, name:"Room B-201", type:"Double", price:3200, total:2, booked:0, icon:"🛌", desc:"Shared double room with balcony." },
  { id:4, name:"Room B-202", type:"Double", price:3200, total:2, booked:1, icon:"🛌", desc:"Spacious double, near common room." },
  { id:5, name:"Room B-203", type:"Double", price:3200, total:2, booked:2, icon:"🛌", desc:"Double room near the cafeteria." },
  { id:6, name:"Dorm C-301", type:"Dormitory", price:1800, total:6, booked:3, icon:"🏨", desc:"6-bed dormitory, budget friendly." },
  { id:7, name:"Dorm C-302", type:"Dormitory", price:1800, total:6, booked:6, icon:"🏨", desc:"Popular dorm, fills up fast." },
  { id:8, name:"Room A-103", type:"Single", price:4800, total:1, booked:0, icon:"🛏️", desc:"Premium single with study desk." },
];

let currentUser = null; // {name, email}
let myBookings = []; // {id, roomId, roomName, type, price, checkIn, guestName, createdAt}
let bookingIdSeq = 1;
let pendingRoomId = null;

// ---------- NAVIGATION ----------
function showView(viewId){
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));

  if(viewId === 'login'){
    document.getElementById('login').classList.add('active');
    return;
  }
  if(viewId === 'myBookings' && !currentUser){
    pendingRoomId = null;
    showView('login');
    flashLoginNote("Please log in to view your bookings.");
    return;
  }

  document.getElementById(viewId).classList.add('active');
  const navLink = document.querySelector(`.nav-link[data-view="${viewId}"]`);
  if(navLink) navLink.classList.add('active');

  if(viewId === 'home') updateHomeStats();
  if(viewId === 'rooms') renderRooms();
  if(viewId === 'myBookings') renderBookings();
}

document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    showView(link.getAttribute('data-view'));
  });
});
document.querySelectorAll('[data-view]').forEach(el => {
  if(!el.classList.contains('nav-link')){
    el.addEventListener('click', () => showView(el.getAttribute('data-view')));
  }
});

function flashLoginNote(msg){
  const err = document.getElementById('loginError');
  err.style.color = '#1e3a5f';
  err.textContent = msg;
}

// ---------- AUTH ----------
function renderAuthArea(){
  const area = document.getElementById('authArea');
  if(currentUser){
    area.innerHTML = `<span class="userTag">👤 ${escapeHtml(currentUser.name)}</span>
      <button class="btn outline" style="padding:6px 12px;font-size:0.85rem;" onclick="handleLogout()">Logout</button>`;
  } else {
    area.innerHTML = `<button class="btn primary" style="padding:6px 14px;font-size:0.85rem;" onclick="showView('login')">Login</button>`;
  }
}

function handleLogin(){
  const name = document.getElementById('loginName').value.trim();
  const email = document.getElementById('loginEmail').value.trim();
  const err = document.getElementById('loginError');
  err.style.color = '#dc2626';

  if(!name || !email){
    err.textContent = "Please enter both name and email.";
    return;
  }
  if(!email.includes('@')){
    err.textContent = "Please enter a valid email.";
    return;
  }
  currentUser = { name, email };
  renderAuthArea();
  err.textContent = "";

  if(pendingRoomId){
    const roomId = pendingRoomId;
    pendingRoomId = null;
    showView('rooms');
    openBookingModal(roomId);
  } else {
    showView('home');
  }
}

function handleLogout(){
  currentUser = null;
  renderAuthArea();
  showView('home');
}

// ---------- HOME STATS ----------
function updateHomeStats(){
  const totalRooms = rooms.reduce((sum, r) => sum + r.total, 0);
  const availableRooms = rooms.reduce((sum, r) => sum + (r.total - r.booked), 0);
  const types = new Set(rooms.map(r => r.type)).size;
  document.getElementById('statTotal').textContent = totalRooms;
  document.getElementById('statAvailable').textContent = availableRooms;
  document.getElementById('statTypes').textContent = types;
}

// ---------- ROOMS ----------
function renderRooms(){
  const grid = document.getElementById('roomGrid');
  const typeFilter = document.getElementById('filterType').value;
  const availFilter = document.getElementById('filterAvailability').value;

  let list = rooms.filter(r => {
    const slotsLeft = r.total - r.booked;
    if(typeFilter !== 'all' && r.type !== typeFilter) return false;
    if(availFilter === 'available' && slotsLeft <= 0) return false;
    return true;
  });

  if(list.length === 0){
    grid.innerHTML = `<div class="empty-state">No rooms match your filters.</div>`;
    return;
  }

  grid.innerHTML = list.map(r => {
    const slotsLeft = r.total - r.booked;
    const isAvailable = slotsLeft > 0;
    return `
      <div class="room-card">
        <div class="room-img">${r.icon}</div>
        <div class="room-body">
          <h3>${escapeHtml(r.name)}</h3>
          <div class="room-meta">${r.type} · ${r.desc}</div>
          <div class="room-price">₹${r.price.toLocaleString()} / month</div>
          <span class="badge ${isAvailable ? 'available' : 'full'}">
            ${isAvailable ? slotsLeft + ' slot(s) available' : 'Fully booked'}
          </span>
          <button class="btn ${isAvailable ? 'primary' : ''}" ${isAvailable ? '' : 'disabled'}
            onclick="openBookingModal(${r.id})">
            ${isAvailable ? 'Book Now' : 'Unavailable'}
          </button>
        </div>
      </div>
    `;
  }).join('');
}

document.getElementById('filterType').addEventListener('change', renderRooms);
document.getElementById('filterAvailability').addEventListener('change', renderRooms);

// ---------- BOOKING MODAL ----------
function openBookingModal(roomId){
  if(!currentUser){
    pendingRoomId = roomId;
    showView('login');
    flashLoginNote("Please log in to book a room.");
    return;
  }
  const room = rooms.find(r => r.id === roomId);
  if(!room) return;
  const slotsLeft = room.total - room.booked;
  if(slotsLeft <= 0){
    alert("Sorry, this room just became fully booked.");
    renderRooms();
    return;
  }

  document.getElementById('modalTitle').textContent = `Book ${room.name}`;
  document.getElementById('modalBody').innerHTML = `
    <label>Guest Name</label>
    <input type="text" id="bookGuestName" value="${escapeHtml(currentUser.name)}">
    <label>Preferred Check-in Date</label>
    <input type="date" id="bookCheckIn">
    <div class="summary">
      <p><strong>Room:</strong> ${escapeHtml(room.name)} (${room.type})</p>
      <p><strong>Price:</strong> ₹${room.price.toLocaleString()} / month</p>
      <p><strong>Slots left:</strong> ${slotsLeft} of ${room.total}</p>
    </div>
    <button class="btn primary full" onclick="confirmBooking(${room.id})">Confirm Booking</button>
  `;
  document.getElementById('bookingModal').classList.add('active');
}

function closeModal(){
  document.getElementById('bookingModal').classList.remove('active');
}

function confirmBooking(roomId){
  const room = rooms.find(r => r.id === roomId);
  if(!room) return;
  const slotsLeft = room.total - room.booked;
  if(slotsLeft <= 0){
    alert("Sorry, this room just became fully booked.");
    closeModal();
    renderRooms();
    return;
  }
  const guestName = document.getElementById('bookGuestName').value.trim();
  const checkIn = document.getElementById('bookCheckIn').value;
  if(!guestName){
    alert("Please enter a guest name.");
    return;
  }
  if(!checkIn){
    alert("Please select a check-in date.");
    return;
  }

  room.booked += 1; // update availability
  myBookings.push({
    id: bookingIdSeq++,
    roomId: room.id,
    roomName: room.name,
    type: room.type,
    price: room.price,
    checkIn,
    guestName,
    createdAt: new Date().toLocaleString()
  });

  closeModal();
  renderRooms();
  alert(`✅ Booking confirmed for ${room.name}!`);
  showView('myBookings');
}

// ---------- MY BOOKINGS ----------
function renderBookings(){
  const list = document.getElementById('bookingsList');
  if(myBookings.length === 0){
    list.innerHTML = `<div class="empty-state">You have no bookings yet. <br><button class="btn primary" style="margin-top:12px;" onclick="showView('rooms')">Browse Rooms</button></div>`;
    return;
  }
  list.innerHTML = myBookings.map(b => `
    <div class="booking-item">
      <div class="info">
        <h4>${escapeHtml(b.roomName)} — ${b.type}</h4>
        <p>Guest: ${escapeHtml(b.guestName)} · Check-in: ${b.checkIn}</p>
        <p>Booked on: ${b.createdAt}</p>
      </div>
      <div>
        <span class="badge available">₹${b.price.toLocaleString()}/mo</span>
        <button class="btn outline" style="margin-left:8px;padding:6px 12px;font-size:0.85rem;" onclick="cancelBooking(${b.id})">Cancel</button>
      </div>
    </div>
  `).join('');
}

function cancelBooking(bookingId){
  const booking = myBookings.find(b => b.id === bookingId);
  if(!booking) return;
  if(!confirm(`Cancel booking for ${booking.roomName}?`)) return;

  const room = rooms.find(r => r.id === booking.roomId);
  if(room) room.booked = Math.max(0, room.booked - 1); // free up the slot

  myBookings = myBookings.filter(b => b.id !== bookingId);
  renderBookings();
}

// ---------- HELPERS ----------
function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---------- INIT ----------
window.addEventListener('click', e => {
  if(e.target.id === 'bookingModal') closeModal();
});

renderAuthArea();
updateHomeStats();
